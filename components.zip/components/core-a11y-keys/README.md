core-a11y-keys
==============

See the [component page](https://www.polymer-project.org/0.5/docs/elements/core-a11y-keys.html) for more information.
