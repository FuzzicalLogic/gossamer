core-component-page
===================

**This element is compatible with Polymer 0.5 and lower only, and will be deprecated.**  
You can check out a similar 0.8-compatible version of this element at [https://github.com/polymerelements/iron-components-page](https://github.com/polymerelements/iron-component-page)

See the [component page](https://www.polymer-project.org/0.5/docs/elements/core-component-page.html) for more information.

Note: this is the vulcanized version of [`core-component-page-dev`](https://github.com/Polymer/core-component-page-dev) (the source).
