core-focusable
==============

owner: @morethanreal

See the [component page](https://www.polymer-project.org/0.5/docs/elements/core-focusable.html) for more information.
