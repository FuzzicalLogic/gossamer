core-icons
=========

**This element is compatible with Polymer 0.5 and lower only, and will be deprecated.**  
You can check out a similar 0.8-compatible version of this element at [https://github.com/polymerelements/iron-icons](https://github.com/polymerelements/iron-icons)

See the [component page](https://www.polymer-project.org/0.5/docs/elements/core-icons.html) for more information.

## Building
Running `update-icons.sh` will checkout [material-design-icons](https://github.com/google/material-design-icons), reduce
the fileset to 24px svgs, and compile the iconsets.
