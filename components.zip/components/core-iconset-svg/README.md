core-iconset-svg
=========

**This element is compatible with Polymer 0.5 and lower only, and will be deprecated.**  
You can check out a similar 0.8-compatible version of this element at [https://github.com/polymerelements/iron-iconset-svg](https://github.com/polymerelements/iron-iconset-svg)

See the [component page](https://www.polymer-project.org/0.5/docs/elements/core-iconset-svg.html) for more information.
