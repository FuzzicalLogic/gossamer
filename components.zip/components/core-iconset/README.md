core-iconset
============

See the [component page](https://www.polymer-project.org/0.5/docs/elements/core-iconset.html) for more information.
