core-shared-lib
===============

See the [component landing page](http://www.polymer-project.org/docs/elements/core-shared-lib.html) for more information.
