htmlSuite('core-shared-lib', function() {
  htmlTest('html/core-shared-lib.html');
});